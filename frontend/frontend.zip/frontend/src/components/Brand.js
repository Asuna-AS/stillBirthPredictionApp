import React from 'react'

const Brand = () => {
    return (
        <div className="flex items-center space-x-4">
            {/* <img src="../../assets/favicon.png" alt="logo" /> */}
            
        </div>
    )
}

export default Brand
